<?php
/**
 * Plugin Name: Green Cabin Direct Checkout Bridge
 * Plugin URI: https://greencabin.lk
 * Description: Connects Green Cabin modern storefront directly to WooCommerce payment checkout.
 * Version: 1.0.0
 * Author: Green Cabin
 * Text Domain: gc-checkout-bridge
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('template_redirect', function() {
    if (isset($_GET['gc_checkout']) && !empty($_GET['items'])) {
        if (!function_exists('WC') || !WC()->cart) {
            return;
        }

        // Empty previous cart
        WC()->cart->empty_cart();

        // Process incoming items (format: ID:QTY,ID:QTY)
        $raw_items = sanitize_text_field(wp_unslash($_GET['items']));
        $items_array = explode(',', $raw_items);
        $added = 0;

        foreach ($items_array as $entry) {
            $parts = explode(':', trim($entry));
            $product_id = isset($parts[0]) ? intval($parts[0]) : 0;
            $quantity = isset($parts[1]) ? intval($parts[1]) : 1;

            if ($product_id > 0 && $quantity > 0) {
                if (WC()->cart->add_to_cart($product_id, $quantity)) {
                    $added++;
                }
            }
        }

        // Redirect directly to Checkout page
        if ($added > 0 || !WC()->cart->is_empty()) {
            wp_safe_redirect(wc_get_checkout_url());
            exit;
        }
    }
}, 5);
