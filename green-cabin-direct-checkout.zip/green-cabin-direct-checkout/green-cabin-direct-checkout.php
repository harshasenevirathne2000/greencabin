<?php
/**
 * Plugin Name: Green Cabin - Direct WooCommerce Checkout Bridge
 * Plugin URI: https://greencabin.lk
 * Description: Connects the Green Cabin modern storefront to WooCommerce checkout. Automatically receives cart items and redirects customers straight to the payment/checkout screen.
 * Version: 1.0.0
 * Author: Green Cabin / Cyril Rodrigo Restaurants
 * Author URI: https://greencabin.lk
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Handle incoming checkout requests from Green Cabin storefront
 * Example URL: https://ordernow.greencabin.lk/?gc_checkout=1&items=20772:2,22772:1
 */
function greencabin_direct_checkout_handler() {
    // Check if this is a Green Cabin direct checkout request
    if (isset($_GET['gc_checkout']) && !empty($_GET['items'])) {
        
        // Ensure WooCommerce and its cart session are active
        if (!function_exists('WC') || !WC()->cart) {
            return;
        }

        // 1. Empty any previous items in the cart
        WC()->cart->empty_cart();

        // 2. Sanitize and parse items parameter
        // Format: ID:QTY,ID:QTY (e.g. 20772:2,22772:1)
        $raw_items = sanitize_text_field(wp_unslash($_GET['items']));
        $items_array = explode(',', $raw_items);
        $added_count = 0;

        foreach ($items_array as $entry) {
            $parts = explode(':', trim($entry));
            $product_id = isset($parts[0]) ? intval($parts[0]) : 0;
            $quantity = isset($parts[1]) ? intval($parts[1]) : 1;

            if ($product_id > 0 && $quantity > 0) {
                // Verify product exists in WooCommerce
                $product = wc_get_product($product_id);
                if ($product && $product->is_purchasable()) {
                    // If it's a variation or simple product, add to cart
                    $result = WC()->cart->add_to_cart($product_id, $quantity);
                    if ($result) {
                        $added_count++;
                    }
                } else {
                    // Try fallback add to cart even if check is strict
                    $result = WC()->cart->add_to_cart($product_id, $quantity);
                    if ($result) {
                        $added_count++;
                    }
                }
            }
        }

        // 3. If items were added, redirect straight to WooCommerce Checkout page
        if ($added_count > 0 || !WC()->cart->is_empty()) {
            wp_safe_redirect(wc_get_checkout_url());
            exit;
        } else {
            // Fallback: If product IDs didn't match, redirect to cart or shop with a notice
            wc_add_notice(__('Items could not be automatically transferred. Please verify product IDs.', 'woocommerce'), 'error');
            wp_safe_redirect(wc_get_cart_url());
            exit;
        }
    }
}
add_action('template_redirect', 'greencabin_direct_checkout_handler', 5);

/**
 * Allow Cross-Origin Requests from Green Cabin domain
 */
function greencabin_direct_checkout_cors() {
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
}
add_action('init', 'greencabin_direct_checkout_cors');
